# lessons/lesson2.py

def lesson2_content():
    return 'This is the content for Lesson 2 - Server Information'
