# lessons/lesson1.py
def hello_name():
    return 'Hello Ravindra Tantuwaya!'


